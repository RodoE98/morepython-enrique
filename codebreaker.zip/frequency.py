# Frequency distribution of letters in multiple languages
# Provided as part of the starter

english = {
    'a': 8.20,
    'b': 1.50,
    'c': 2.80,
    'd': 4.30,
    'e': 13,
    'f': 2.20,
    'g': 2,
    'h': 6.10,
    'i': 7,
    'j': 0.15,
    'k': 0.77,
    'l': 4,
    'm': 2.40,
    'n': 6.70,
    'o': 7.50,
    'p': 1.90,
    'q': 0.10,
    'r': 6,
    's': 6.30,
    't': 9.10,
    'u': 2.80,
    'v': 0.98,
    'w': 2.40,
    'x': 0.15,
    'y': 2,
    'z': 0.07
}
